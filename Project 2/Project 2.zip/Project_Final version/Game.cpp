/* 
 * File:   Game.cpp
 * Author: Juanathan Balisky
 * Created on 11,19,2015
 * Purpose: Implementation isValid
 */

#include"Game.h"
//ch 15 inheritance (i spell it right!!!)
//ch 16 template
/**
 * 
 * @param level //see?
 */
