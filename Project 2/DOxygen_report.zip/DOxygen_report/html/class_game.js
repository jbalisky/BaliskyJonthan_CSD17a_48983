var class_game =
[
    [ "Game", "class_game.html#a8d00e68144fea1d245b30021ff9a5d9b", null ],
    [ "~Game", "class_game.html#ac98b054acf64c7ac2c7c780e79b4f618", null ],
    [ "compare", "class_game.html#a9e6bcc1ae8e19bc25b9cfa39beb29c5a", null ],
    [ "getGuess", "class_game.html#a08ac615fa1cf399c206bcadf47109388", null ],
    [ "getOs", "class_game.html#a1ccc9a160aa4c0617142efbd8f654945", null ],
    [ "getSAns", "class_game.html#a89e9b1725d7e2e8eb3996837784e7ec4", null ],
    [ "getXs", "class_game.html#acff364fb95406f49b3b0028037a787f5", null ],
    [ "gssHst", "class_game.html#ad5e14b31647a4da393b4837d89ba57e1", null ],
    [ "sort", "class_game.html#ae7b3779e9ea40bceff534c31a1b4b9be", null ]
];