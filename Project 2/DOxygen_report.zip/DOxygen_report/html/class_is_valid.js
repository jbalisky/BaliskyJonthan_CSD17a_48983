var class_is_valid =
[
    [ "IsValid", "class_is_valid.html#ad8de07083cbd328b8643445583140ed1", null ],
    [ "setLevel", "class_is_valid.html#ad666e24d961a3502e76769cbe4194158", null ],
    [ "setUserG", "class_is_valid.html#a9b09b29e31ae25d4beb6821e699c11ce", null ],
    [ "validate", "class_is_valid.html#aa658b1bd8bb71b55e62249047e39e938", null ],
    [ "level", "class_is_valid.html#ad803e4f443a19d48af63effafc3ae527", null ],
    [ "usrG", "class_is_valid.html#adbf865b1f62a0967106b899e15bbc6cb", null ]
];