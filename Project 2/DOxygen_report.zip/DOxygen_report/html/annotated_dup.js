var annotated_dup =
[
    [ "Game", "class_game.html", "class_game" ],
    [ "IsValid", "class_is_valid.html", "class_is_valid" ]
];