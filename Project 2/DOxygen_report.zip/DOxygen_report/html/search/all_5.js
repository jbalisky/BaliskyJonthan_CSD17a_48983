var searchData=
[
  ['setlevel',['setLevel',['../class_is_valid.html#ad666e24d961a3502e76769cbe4194158',1,'IsValid']]],
  ['setuserg',['setUserG',['../class_is_valid.html#a9b09b29e31ae25d4beb6821e699c11ce',1,'IsValid']]],
  ['sort',['sort',['../class_game.html#ae7b3779e9ea40bceff534c31a1b4b9be',1,'Game']]]
];
