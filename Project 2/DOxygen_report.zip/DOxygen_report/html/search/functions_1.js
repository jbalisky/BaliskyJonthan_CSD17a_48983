var searchData=
[
  ['game',['Game',['../class_game.html#a8d00e68144fea1d245b30021ff9a5d9b',1,'Game']]],
  ['getguess',['getGuess',['../class_game.html#a08ac615fa1cf399c206bcadf47109388',1,'Game']]],
  ['getos',['getOs',['../class_game.html#a1ccc9a160aa4c0617142efbd8f654945',1,'Game']]],
  ['getsans',['getSAns',['../class_game.html#a89e9b1725d7e2e8eb3996837784e7ec4',1,'Game']]],
  ['getxs',['getXs',['../class_game.html#acff364fb95406f49b3b0028037a787f5',1,'Game']]],
  ['gsshst',['gssHst',['../class_game.html#ad5e14b31647a4da393b4837d89ba57e1',1,'Game']]]
];
