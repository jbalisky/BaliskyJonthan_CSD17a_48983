var searchData=
[
  ['isvalid',['IsValid',['../class_is_valid.html',1,'']]]
];
