var hierarchy =
[
    [ "IsValid", "class_is_valid.html", [
      [ "Game< T >", "class_game.html", null ]
    ] ]
];